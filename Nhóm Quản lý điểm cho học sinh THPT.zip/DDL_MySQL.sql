USE qlhs_java;

-- Academic Year
CREATE TABLE Academic_Year (
    Year_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Academic_Year VARCHAR(255) NOT NULL
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Role
CREATE TABLE Role (
    Role_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Role_Name VARCHAR(255) NOT NULL
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Account
CREATE TABLE Account (
    Account_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Email VARCHAR(255) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Role_ID CHAR(36),
    FOREIGN KEY (Role_ID) REFERENCES Role(Role_ID)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Subject
CREATE TABLE Subject (
    Subject_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Subject_Name VARCHAR(255) NOT NULL
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Teacher
CREATE TABLE Teacher (
    Teacher_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Name VARCHAR(255) NOT NULL,
    Birthday DATE NOT NULL,
    Gender VARCHAR(10) NOT NULL,
    Phone VARCHAR(20),
    Subject_ID CHAR(36),
    Account_ID CHAR(36),
    FOREIGN KEY (Subject_ID) REFERENCES Subject(Subject_ID),
    FOREIGN KEY (Account_ID) REFERENCES Account(Account_ID)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Class
CREATE TABLE Class (
    Class_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Class_Name VARCHAR(255) NOT NULL,
    Grade INT NOT NULL,
    Homeroom_Teacher CHAR(36),
    FOREIGN KEY (Homeroom_Teacher) REFERENCES Teacher(Teacher_ID)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Class Assignment
CREATE TABLE Class_Assignment (
    Assignment_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Class_ID CHAR(36),
    Teacher_ID CHAR(36),
    FOREIGN KEY (Class_ID) REFERENCES Class(Class_ID),
    FOREIGN KEY (Teacher_ID) REFERENCES Teacher(Teacher_ID)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Student
CREATE TABLE Student (
    Student_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Name VARCHAR(255) NOT NULL,
    Birthday DATE NOT NULL,
    Gender VARCHAR(10) NOT NULL,
    Phone VARCHAR(20),
    School_Year INT NOT NULL,
    Class_ID CHAR(36),
    Account_ID CHAR(36),
    FOREIGN KEY (Class_ID) REFERENCES Class(Class_ID),
    FOREIGN KEY (Account_ID) REFERENCES Account(Account_ID)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Grade
CREATE TABLE Grade (
    Grade_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Semester INT NOT NULL,
    Grade_Name VARCHAR(255) NOT NULL,
    Coefficient FLOAT NOT NULL
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- Report Card
CREATE TABLE Report_Card (
    Report_Card_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Year_ID CHAR(36),
    Student_ID CHAR(36),
    Assignment_ID CHAR(36),
    FOREIGN KEY (Year_ID) REFERENCES Academic_Year(Year_ID),
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    FOREIGN KEY (Assignment_ID) REFERENCES Class_Assignment(Assignment_ID)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Detailed Report Card
CREATE TABLE Detailed_Report_Card (
    Detail_ID CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    Grade_ID CHAR(36),
    Score FLOAT NOT NULL,
    Report_Card_ID CHAR(36),
    FOREIGN KEY (Grade_ID) REFERENCES Grade(Grade_ID),
    FOREIGN KEY (Report_Card_ID) REFERENCES Report_Card(Report_Card_ID)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
