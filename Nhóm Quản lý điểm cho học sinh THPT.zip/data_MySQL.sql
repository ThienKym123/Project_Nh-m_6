
-- Insert data for 3 academic years
INSERT INTO Academic_Year (Year_ID, Academic_Year)
VALUES 
    (UUID(), '2021-2022'),
    (UUID(), '2022-2023'),
    (UUID(), '2023-2024');

-- Insert roles into the Role table
INSERT INTO Role (Role_ID, Role_Name)
VALUES 
    (UUID(), 'Giáo viên chủ nhiệm'), -- Homeroom Teacher
    (UUID(), 'Giáo viên bộ môn'), -- Subject Teacher
    (UUID(), 'trưởng'), 	-- Monitor
    (UUID(), 'Học sinh');    -- Student


-- Insert subjects into the Subject table
INSERT INTO Subject (Subject_ID, Subject_Name)
VALUES 
    (UUID(), 'Toán'),
    (UUID(), 'Ngữ Văn'),
    (UUID(), 'Tiếng Anh');


-- Insert accounts for teachers
INSERT INTO Account (Account_ID, Email, Password, Role_ID)
VALUES 
    -- Toán
    (UUID(), 'teacher.toan1@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên chủ nhiệm')),
    (UUID(), 'teacher.toan2@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên chủ nhiệm')),
    (UUID(), 'teacher.toan3@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên bộ môn')),
    -- Ngữ Văn
    (UUID(), 'teacher.nguvan1@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên chủ nhiệm')),
    (UUID(), 'teacher.nguvan2@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên chủ nhiệm')),
    (UUID(), 'teacher.nguvan3@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên bộ môn')),

    -- Tiếng Anh
    (UUID(), 'teacher.tienganh1@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên chủ nhiệm')),
    (UUID(), 'teacher.tienganh2@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên chủ nhiệm')),
    (UUID(), 'teacher.tienganh3@example.com', 'password', (SELECT Role_ID FROM Role WHERE Role_Name = 'Giáo viên bộ môn'));


-- Insert teachers into the Teacher table
INSERT INTO Teacher (Teacher_ID, Name, Birthday, Gender, Phone, Subject_ID, Account_ID)
VALUES 
    -- Toán
    (UUID(), 'Teacher Toán 1', '1980-01-01', 'Nam', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Toán'),
     (SELECT Account_ID FROM Account WHERE Email ='teacher.toan1@example.com')),

    (UUID(), 'Teacher Toán 2', '1981-02-01', 'Nữ', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Toán'),
     (SELECT Account_ID FROM Account WHERE Email = 'teacher.toan2@example.com')),

    (UUID(), 'Teacher Toán 3', '1982-03-01', 'Nam', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Toán'),
     (SELECT Account_ID FROM Account WHERE Email = 'teacher.toan3@example.com')),

    -- Ngữ Văn
    (UUID(), 'Teacher Ngữ Văn 1', '1989-10-01', 'Nữ', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Ngữ Văn'),
     (SELECT Account_ID FROM Account WHERE Email = 'teacher.nguvan1@example.com')),

    (UUID(), 'Teacher Ngữ Văn 2', '1990-11-01', 'Nam', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Ngữ Văn'),
     (SELECT Account_ID FROM Account WHERE Email = 'teacher.nguvan2@example.com')),

    (UUID(), 'Teacher Ngữ Văn 3', '1991-12-01', 'Nữ', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Ngữ Văn'),
     (SELECT Account_ID FROM Account WHERE Email = 'teacher.nguvan3@example.com')),

    -- Tiếng Anh
    (UUID(), 'Teacher Tiếng Anh 1', '1992-01-01', 'Nam', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Tiếng Anh'),
     (SELECT Account_ID FROM Account WHERE Email = 'teacher.tienganh1@example.com')),

    (UUID(), 'Teacher Tiếng Anh 2', '1993-02-01', 'Nữ', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Tiếng Anh'),
     (SELECT Account_ID FROM Account WHERE Email = 'teacher.tienganh2@example.com')),

    (UUID(), 'Teacher Tiếng Anh 3', '1994-03-01', 'Nam', '0123456789', 
     (SELECT Subject_ID FROM Subject WHERE Subject_Name = 'Tiếng Anh'),
     (SELECT Account_ID FROM Account WHERE Email = 'teacher.tienganh3@example.com'));
   
   
-- Insert classes into the Class table
INSERT INTO Class (Class_ID, Class_Name, Grade, Homeroom_Teacher)
VALUES 
    (UUID(), '10A1', 10, (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Toán 1')),
    (UUID(), '10A2', 10, (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Toán 2')),
    (UUID(), '11A1', 11, (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Ngữ Văn 1')),
    (UUID(), '11A2', 11, (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Ngữ Văn 2')),
    (UUID(), '12A1', 12, (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Tiếng Anh 1')),
    (UUID(), '12A2', 12, (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Tiếng Anh 2'));

   
-- Insert class assignments for each class ensuring unique teachers for each subject
-- Lớp 10A1
INSERT INTO Class_Assignment (Assignment_ID, Class_ID, Teacher_ID)
VALUES 
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '10A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Toán 1')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '10A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Ngữ Văn 1')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '10A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Tiếng Anh 1'));

-- Lớp 10A2
INSERT INTO Class_Assignment (Assignment_ID, Class_ID, Teacher_ID)
VALUES 
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '10A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Toán 2')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '10A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Ngữ Văn 2')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '10A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Tiếng Anh 2'));

-- Lớp 11A1
INSERT INTO Class_Assignment (Assignment_ID, Class_ID, Teacher_ID)
VALUES 
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '11A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Toán 1')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '11A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Ngữ Văn 1')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '11A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Tiếng Anh 1'));

-- Lớp 11A2
INSERT INTO Class_Assignment (Assignment_ID, Class_ID, Teacher_ID)
VALUES 
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '11A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Toán 2')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '11A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Ngữ Văn 2')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '11A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Tiếng Anh 2'));

-- Lớp 12A1
INSERT INTO Class_Assignment (Assignment_ID, Class_ID, Teacher_ID)
VALUES 
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '12A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Toán 1')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '12A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Ngữ Văn 1')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '12A1'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Tiếng Anh 1'));

-- Lớp 12A2
INSERT INTO Class_Assignment (Assignment_ID, Class_ID, Teacher_ID)
VALUES 
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '12A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Toán 2')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '12A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Ngữ Văn 2')),
    (UUID(), (SELECT Class_ID FROM Class WHERE Class_Name = '12A2'), (SELECT Teacher_ID FROM Teacher WHERE Name = 'Teacher Tiếng Anh 2'));

SELECT 
    ca.Assignment_ID, 
    c.Class_Name, 
    t.Name AS Teacher_Name, 
    s.Subject_Name, 
    r.Role_Name
FROM 
    Class_Assignment ca
    JOIN Class c ON ca.Class_ID = c.Class_ID
    JOIN Teacher t ON ca.Teacher_ID = t.Teacher_ID
    JOIN Subject s ON t.Subject_ID = s.Subject_ID
    JOIN Account a ON t.Account_ID = a.Account_ID
    JOIN Role r ON a.Role_ID = r.Role_ID
ORDER BY 
    c.Class_Name, 
    r.Role_Name, 
    t.Name;

-- Insert Account Records for 36 Students
INSERT INTO Account (Account_ID, Email, Password, Role_ID)
VALUES
    -- Class 10A1
    (UUID(), 'Student_10A1_1@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),
    (UUID(), 'Student_10A1_2@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),

    -- Class 10A2
    (UUID(), 'Student_10A2_1@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),
    (UUID(), 'Student_10A2_2@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),

    -- Class 11A1
    (UUID(), 'Student_11A1_1@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),
    (UUID(), 'Student_11A1_2@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),

    -- Class 11A2
    (UUID(), 'Student_11A2_1@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),
    (UUID(), 'Student_11A2_2@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),

    -- Class 12A1
    (UUID(), 'Student_12A1_1@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),
    (UUID(), 'Student_12A1_2@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),

    -- Class 12A2
    (UUID(), 'Student_12A2_1@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),
    (UUID(), 'Student_12A2_2@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),

    -- Class 12A3
    (UUID(), 'Student_12A3_1@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh')),
    (UUID(), 'Student_12A3_2@st.com', 'password123', (SELECT Role_ID FROM Role WHERE Role_Name = 'Học sinh'));


-- Insert Students for 36 Students with Account_IDs
INSERT INTO Student (Student_ID, Name, Birthday, Gender, Phone, School_Year, Class_ID, Account_ID)
VALUES
    -- Class 10A1
    (UUID(), 'Student_10A1_1', '2007-01-15', 'Nam', '0123456789', 1, (SELECT Class_ID FROM Class WHERE Class_Name = '10A1'), (SELECT Account_ID FROM Account WHERE Email = 'Student_10A1_1@st.com')),
    (UUID(), 'Student_10A1_2', '2007-02-20', 'Nữ', '0123456789', 1, (SELECT Class_ID FROM Class WHERE Class_Name = '10A1'), (SELECT Account_ID FROM Account WHERE Email = 'Student_10A1_2@st.com')),

    -- Class 10A2
    (UUID(), 'Student_10A2_1', '2007-05-15', 'Nam', '0123456789', 1, (SELECT Class_ID FROM Class WHERE Class_Name = '10A2'), (SELECT Account_ID FROM Account WHERE Email = 'Student_10A2_1@st.com')),
    (UUID(), 'Student_10A2_2', '2007-06-10', 'Nữ', '0123456789', 1, (SELECT Class_ID FROM Class WHERE Class_Name = '10A2'), (SELECT Account_ID FROM Account WHERE Email = 'Student_10A2_2@st.com')),

    -- Class 11A1
    (UUID(), 'Student_11A1_1', '2006-01-25', 'Nam', '0123456789', 2, (SELECT Class_ID FROM Class WHERE Class_Name = '11A1'), (SELECT Account_ID FROM Account WHERE Email = 'Student_11A1_1@st.com')),
    (UUID(), 'Student_11A1_2', '2006-02-15', 'Nữ', '0123456789', 2, (SELECT Class_ID FROM Class WHERE Class_Name = '11A1'), (SELECT Account_ID FROM Account WHERE Email = 'Student_11A1_2@st.com')),

    -- Class 11A2
    (UUID(), 'Student_11A2_1', '2006-05-15', 'Nam', '0123456789', 2, (SELECT Class_ID FROM Class WHERE Class_Name = '11A2'), (SELECT Account_ID FROM Account WHERE Email = 'Student_11A2_1@st.com')),
    (UUID(), 'Student_11A2_2', '2006-06-10', 'Nữ', '0123456789', 2, (SELECT Class_ID FROM Class WHERE Class_Name = '11A2'), (SELECT Account_ID FROM Account WHERE Email = 'Student_11A2_2@st.com')),

    -- Class 12A1
    (UUID(), 'Student_12A1_1', '2005-01-15', 'Nam', '0123456789', 3, (SELECT Class_ID FROM Class WHERE Class_Name = '12A1'), (SELECT Account_ID FROM Account WHERE Email = 'Student_12A1_1@st.com')),
    (UUID(), 'Student_12A1_2', '2005-02-20', 'Nữ', '0123456789', 3, (SELECT Class_ID FROM Class WHERE Class_Name = '12A1'), (SELECT Account_ID FROM Account WHERE Email = 'Student_12A1_2@st.com')),

    -- Class 12A2
    (UUID(), 'Student_12A2_1', '2005-05-15', 'Nam', '0123456789', 3, (SELECT Class_ID FROM Class WHERE Class_Name = '12A2'), (SELECT Account_ID FROM Account WHERE Email = 'Student_12A2_1@st.com')),
    (UUID(), 'Student_12A2_2', '2005-06-10', 'Nữ', '0123456789', 3, (SELECT Class_ID FROM Class WHERE Class_Name = '12A2'), (SELECT Account_ID FROM Account WHERE Email = 'Student_12A2_2@st.com')),

    -- Class 12A3
    (UUID(), 'Student_12A3_1', '2005-09-15', 'Nam', '0123456789', 3, (SELECT Class_ID FROM Class WHERE Class_Name = '12A3'), (SELECT Account_ID FROM Account WHERE Email = 'Student_12A3_1@st.com')),
    (UUID(), 'Student_12A3_2', '2005-10-10', 'Nữ', '0123456789', 3, (SELECT Class_ID FROM Class WHERE Class_Name = '12A3'), (SELECT Account_ID FROM Account WHERE Email = 'Student_12A3_2@st.com'));


-- Insert grade categories into the Grade table
INSERT INTO Grade (Grade_ID, Semester, Grade_Name, Coefficient)
VALUES 
    (UUID(), 1, 'Miệng lần 1', 1),
    (UUID(), 1, 'Miệng lần 2', 1),
    (UUID(), 1, '15p lần 1', 1),
    (UUID(), 1, '15p lần 2', 1),
    (UUID(), 1, '1 Tiết', 2),
    (UUID(), 1, 'Giữa kì', 2),
    (UUID(), 1, 'Cuối kì', 3),
    
    (UUID(), 2, 'Miệng lần 1', 1),
    (UUID(), 2, 'Miệng lần 2', 1),
    (UUID(), 2, '15p lần 1', 1),
    (UUID(), 2, '15p lần 2', 1),
    (UUID(), 2, '1 Tiết', 2),
    (UUID(), 2, 'Giữa kì', 2),
    (UUID(), 2, 'Cuối kì', 3);


-- Step 1: Fetch the Year_ID for the year '2023-2024'
SET @Year2023_2024 := (SELECT Year_ID FROM Academic_Year WHERE Academic_Year = '2023-2024');

-- Step 2: Insert Report Cards for the academic year 2023-2024
INSERT INTO Report_Card (Report_Card_ID, Year_ID, Student_ID, Assignment_ID)
SELECT 
    UUID() AS Report_Card_ID,
    @Year2023_2024 AS Year_ID,
    s.Student_ID,
    ca.Assignment_ID
FROM Student s 
JOIN Class_Assignment ca ON s.Class_ID = ca.Class_ID;

SELECT 
    
    ay.Academic_Year, 
    s.Name AS Student_Name, 
    c.Class_Name, 
    t.Name AS Teacher_Name, 
    sub.Subject_Name
FROM 
    Report_Card rc
JOIN 
    Academic_Year ay ON rc.Year_ID = ay.Year_ID
JOIN 
    Student s ON rc.Student_ID = s.Student_ID
JOIN 
    Class_Assignment ca ON rc.Assignment_ID = ca.Assignment_ID
JOIN 
    Class c ON ca.Class_ID = c.Class_ID
JOIN 
    Teacher t ON ca.Teacher_ID = t.Teacher_ID
JOIN 
    Subject sub ON t.Subject_ID = sub.Subject_ID
ORDER BY 
    rc.Report_Card_ID;


