package com.example.mySQL.service;

import com.example.mySQL.model.Class;
import com.example.mySQL.repository.ClassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClassService {

    @Autowired
    private ClassRepository classRepository;

    // Get all classes
    public List<Class> getAllClasses() {
        return classRepository.findAll();
    }

    // Get class by ID
    public Class getClassById(String id) {
        Optional<Class> classOpt = classRepository.findById(id);
        return classOpt.orElse(null);
    }

    // Create a new class
    public Class createClass(Class clazz) {
        return classRepository.save(clazz);
    }

    // Update class by ID
    public Class updateClass(String id, Class clazz) {
        if (classRepository.existsById(id)) {
            clazz.setClassId(id);
            return classRepository.save(clazz);
        }
        return null;
    }

    // Delete class by ID
    public boolean deleteClass(String id) {
        if (classRepository.existsById(id)) {
            classRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
