package com.example.mySQL.service;

import com.example.mySQL.model.ReportCard;
import com.example.mySQL.repository.ReportCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReportCardService {

    @Autowired
    private ReportCardRepository reportCardRepository;

    public List<ReportCard> getAllReportCards() {
        return reportCardRepository.findAll();
    }

    public ReportCard getReportCardById(String id) {
        Optional<ReportCard> reportCard = reportCardRepository.findById(id);
        return reportCard.orElse(null);
    }

    public ReportCard createReportCard(ReportCard reportCard) {
        return reportCardRepository.save(reportCard);
    }

    public ReportCard updateReportCard(String id, ReportCard reportCard) {
        if (reportCardRepository.existsById(id)) {
            reportCard.setReportCardId(id);
            return reportCardRepository.save(reportCard);
        }
        return null;
    }

    public boolean deleteReportCard(String id) {
        if (reportCardRepository.existsById(id)) {
            reportCardRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
