package com.example.mySQL.controller;

import com.example.mySQL.model.ReportCard;
import com.example.mySQL.service.ReportCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reportCards")
public class ReportCardController {

    @Autowired
    private ReportCardService reportCardService;

    @GetMapping
    public List<ReportCard> getAllReportCards() {
        return reportCardService.getAllReportCards();
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getReportCardById(@PathVariable String id) {
        ReportCard reportCard = reportCardService.getReportCardById(id);
        if (reportCard != null) {
            return ResponseEntity.ok(reportCard.toString());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Report Card with ID " + id + " not found.");
    }

    @PostMapping
    public ResponseEntity<String> createReportCard(@RequestBody ReportCard reportCard) {
        ReportCard createdReportCard = reportCardService.createReportCard(reportCard);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Report Card created with ID: " + createdReportCard.getReportCardId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateReportCard(@PathVariable String id, @RequestBody ReportCard reportCard) {
        ReportCard updatedReportCard = reportCardService.updateReportCard(id, reportCard);
        if (updatedReportCard != null) {
            return ResponseEntity.ok("Report Card with ID " + id + " has been updated successfully.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Report Card with ID " + id + " not found.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteReportCard(@PathVariable String id) {
        boolean isDeleted = reportCardService.deleteReportCard(id);
        if (isDeleted) {
            return ResponseEntity.ok("Report Card with ID " + id + " has been deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Report Card with ID " + id + " not found.");
        }
    }
}
