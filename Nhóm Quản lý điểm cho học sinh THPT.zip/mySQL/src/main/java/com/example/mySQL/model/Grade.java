package com.example.mySQL.model;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "Grade")
public class Grade {

    @Id
    @Column(name = "Grade_ID", columnDefinition = "CHAR(36)")
    private String gradeId;

    @Column(name = "Semester", nullable = false)
    private int semester;

    @Column(name = "Grade_Name", nullable = false, length = 255)
    private String gradeName;

    @Column(name = "Coefficient", nullable = false)
    private float coefficient;

    public Grade() {
        this.gradeId = UUID.randomUUID().toString();
    }

    // Getters and Setters
    public String getGradeId() {
        return gradeId;
    }

    public void setGradeId(String gradeId) {
        this.gradeId = gradeId;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public float getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(float coefficient) {
        this.coefficient = coefficient;
    }
}
