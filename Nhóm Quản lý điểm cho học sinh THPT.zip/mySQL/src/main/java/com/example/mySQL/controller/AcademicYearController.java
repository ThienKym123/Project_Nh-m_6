package com.example.mySQL.controller;

import com.example.mySQL.model.AcademicYear;
import com.example.mySQL.service.AcademicYearService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/academic-years")
public class AcademicYearController {

    @Autowired
    private AcademicYearService academicYearService;

    @GetMapping
    public ResponseEntity<List<AcademicYear>> getAllAcademicYears() {
        List<AcademicYear> academicYears = academicYearService.getAllAcademicYears();
        if (academicYears.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }
        return ResponseEntity.ok(academicYears);
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getAcademicYearById(@PathVariable String id) {
        AcademicYear academicYear = academicYearService.getAcademicYearById(id);
        if (academicYear != null) {
            return ResponseEntity.ok("Academic Year: " + academicYear.getAcademicYear()); // Customize response as needed
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Academic Year with ID " + id + " not found.");
    }

    @PostMapping
    public ResponseEntity<String> createAcademicYear(@RequestBody AcademicYear academicYear) {
        AcademicYear createdYear = academicYearService.createAcademicYear(academicYear);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Academic Year created with ID: " + createdYear.getYearId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateAcademicYear(@PathVariable String id, @RequestBody AcademicYear academicYear) {
        AcademicYear updatedYear = academicYearService.updateAcademicYear(id, academicYear);
        if (updatedYear != null) {
            return ResponseEntity.ok("Academic Year with ID " + id + " has been updated successfully.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Academic Year with ID " + id + " not found.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAcademicYear(@PathVariable String id) {
        boolean isDeleted = academicYearService.deleteAcademicYear(id);
        if (isDeleted) {
            return ResponseEntity.ok("Academic Year with ID " + id + " has been deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Academic Year with ID " + id + " not found.");
        }
    }
}
