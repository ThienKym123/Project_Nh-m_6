package com.example.mySQL.service;

import com.example.mySQL.model.AcademicYear;
import com.example.mySQL.model.Role;
import com.example.mySQL.repository.AcademicYearRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AcademicYearService {

    @Autowired
    private AcademicYearRepository academicYearRepository;

    public List<AcademicYear> getAllAcademicYears(){
        return academicYearRepository.findAll();
    }

    public AcademicYear getAcademicYearById(String id) {
        Optional<AcademicYear> academicYear = academicYearRepository.findById(id);
        return academicYear.orElse(null);
    }

    public AcademicYear createAcademicYear(AcademicYear academicYear){
        return academicYearRepository.save(academicYear);
    }

    public AcademicYear updateAcademicYear(String id, AcademicYear academicYear){
        Optional<AcademicYear> existingAcademicYear = academicYearRepository.findById(id);
        if (existingAcademicYear.isPresent()){
            AcademicYear updatedYear = existingAcademicYear.get();
            updatedYear.setAcademicYear(academicYear.getAcademicYear());
            return academicYearRepository.save(updatedYear); // Save updatedYear instead of academicYear
        }
        return null;
    }

    public boolean deleteAcademicYear(String id){
        if (academicYearRepository.existsById(id)) {
            academicYearRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
