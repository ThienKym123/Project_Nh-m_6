package com.example.mySQL.service;

import com.example.mySQL.model.Grade;
import com.example.mySQL.repository.GradeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GradeService {

    @Autowired
    private GradeRepository gradeRepository;

    public List<Grade> getAllGrades() {
        return gradeRepository.findAll();
    }

    public Grade getGradeById(String id) {
        Optional<Grade> grade = gradeRepository.findById(id);
        return grade.orElse(null);
    }

    public Grade createGrade(Grade grade) {
        return gradeRepository.save(grade);
    }

    public Grade updateGrade(String id, Grade grade) {
        if (gradeRepository.existsById(id)) {
            grade.setGradeId(id);
            return gradeRepository.save(grade);
        }
        return null;
    }

    public boolean deleteGrade(String id) {
        if (gradeRepository.existsById(id)) {
            gradeRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
