package com.example.mySQL.controller;

import com.example.mySQL.model.Subject;
import com.example.mySQL.service.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/subjects")
public class SubjectController {

    @Autowired
    private SubjectService subjectService;

    @GetMapping
    public List<Subject> getAllSubjects() {
        return subjectService.getAllSubjects();
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getSubjectById(@PathVariable String id) {
        Subject subject = subjectService.getSubjectById(id);
        if (subject != null) {
            return ResponseEntity.ok(subject.toString());  // Customize response as needed
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Subject with ID " + id + " not found.");
    }

    @PostMapping
    public ResponseEntity<String> createSubject(@RequestBody Subject subject) {
        Subject createdSubject = subjectService.createSubject(subject);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Subject created with ID: " + createdSubject.getSubjectId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateSubject(@PathVariable String id, @RequestBody Subject subject) {
        Subject updatedSubject = subjectService.updateSubject(id, subject);
        if (updatedSubject != null) {
            return ResponseEntity.ok("Subject with ID " + id + " has been updated successfully.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Subject with ID " + id + " not found.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteSubject(@PathVariable String id) {
        boolean isDeleted = subjectService.deleteSubject(id);
        if (isDeleted) {
            return ResponseEntity.ok("Subject with ID " + id + " has been deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Subject with ID " + id + " not found.");
        }
    }
}
