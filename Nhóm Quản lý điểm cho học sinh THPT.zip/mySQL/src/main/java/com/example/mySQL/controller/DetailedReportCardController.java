package com.example.mySQL.controller;

import com.example.mySQL.model.DetailedReportCard;
import com.example.mySQL.service.DetailedReportCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/detailedReportCards")
public class DetailedReportCardController {

    @Autowired
    private DetailedReportCardService detailedReportCardService;

    @GetMapping
    public List<DetailedReportCard> getAllDetailedReportCards() {
        return detailedReportCardService.getAllDetailedReportCards();
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getDetailedReportCardById(@PathVariable String id) {
        DetailedReportCard detailedReportCard = detailedReportCardService.getDetailedReportCardById(id);
        if (detailedReportCard != null) {
            return ResponseEntity.ok(detailedReportCard.toString());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Detailed Report Card with ID " + id + " not found.");
    }

    @PostMapping
    public ResponseEntity<String> createDetailedReportCard(@RequestBody DetailedReportCard detailedReportCard) {
        DetailedReportCard createdDetailedReportCard = detailedReportCardService.createDetailedReportCard(detailedReportCard);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Detailed Report Card created with ID: " + createdDetailedReportCard.getDetailId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateDetailedReportCard(@PathVariable String id, @RequestBody DetailedReportCard detailedReportCard) {
        DetailedReportCard updatedDetailedReportCard = detailedReportCardService.updateDetailedReportCard(id, detailedReportCard);
        if (updatedDetailedReportCard != null) {
            return ResponseEntity.ok("Detailed Report Card with ID " + id + " has been updated successfully.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Detailed Report Card with ID " + id + " not found.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDetailedReportCard(@PathVariable String id) {
        boolean isDeleted = detailedReportCardService.deleteDetailedReportCard(id);
        if (isDeleted) {
            return ResponseEntity.ok("Detailed Report Card with ID " + id + " has been deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Detailed Report Card with ID " + id + " not found.");
        }
    }
}
