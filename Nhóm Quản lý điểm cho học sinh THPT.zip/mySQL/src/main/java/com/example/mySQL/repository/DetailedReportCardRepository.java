package com.example.mySQL.repository;

import com.example.mySQL.model.DetailedReportCard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetailedReportCardRepository extends JpaRepository<DetailedReportCard, String> {
}
