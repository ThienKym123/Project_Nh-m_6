package com.example.mySQL.service;

import com.example.mySQL.model.DetailedReportCard;
import com.example.mySQL.repository.DetailedReportCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DetailedReportCardService {

    @Autowired
    private DetailedReportCardRepository detailedReportCardRepository;

    public List<DetailedReportCard> getAllDetailedReportCards() {
        return detailedReportCardRepository.findAll();
    }

    public DetailedReportCard getDetailedReportCardById(String id) {
        Optional<DetailedReportCard> detailedReportCard = detailedReportCardRepository.findById(id);
        return detailedReportCard.orElse(null);
    }

    public DetailedReportCard createDetailedReportCard(DetailedReportCard detailedReportCard) {
        return detailedReportCardRepository.save(detailedReportCard);
    }

    public DetailedReportCard updateDetailedReportCard(String id, DetailedReportCard detailedReportCard) {
        if (detailedReportCardRepository.existsById(id)) {
            detailedReportCard.setDetailId(id);
            return detailedReportCardRepository.save(detailedReportCard);
        }
        return null;
    }

    public boolean deleteDetailedReportCard(String id) {
        if (detailedReportCardRepository.existsById(id)) {
            detailedReportCardRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
