package com.example.mySQL.repository;

import com.example.mySQL.model.ClassAssignment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassAssignmentRepository extends JpaRepository<ClassAssignment, String> {
}
