package com.example.mySQL.repository;

import com.example.mySQL.model.ReportCard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportCardRepository extends JpaRepository<ReportCard, String> {
}
