package com.example.mySQL.controller;

import com.example.mySQL.model.Grade;
import com.example.mySQL.service.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grades")
public class GradeController {

    @Autowired
    private GradeService gradeService;

    @GetMapping
    public List<Grade> getAllGrades() {
        return gradeService.getAllGrades();
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getGradeById(@PathVariable String id) {
        Grade grade = gradeService.getGradeById(id);
        if (grade != null) {
            return ResponseEntity.ok(grade.toString());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Grade with ID " + id + " not found.");
    }

    @PostMapping
    public ResponseEntity<String> createGrade(@RequestBody Grade grade) {
        Grade createdGrade = gradeService.createGrade(grade);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Grade created with ID: " + createdGrade.getGradeId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateGrade(@PathVariable String id, @RequestBody Grade grade) {
        Grade updatedGrade = gradeService.updateGrade(id, grade);
        if (updatedGrade != null) {
            return ResponseEntity.ok("Grade with ID " + id + " has been updated successfully.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Grade with ID " + id + " not found.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteGrade(@PathVariable String id) {
        boolean isDeleted = gradeService.deleteGrade(id);
        if (isDeleted) {
            return ResponseEntity.ok("Grade with ID " + id + " has been deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Grade with ID " + id + " not found.");
        }
    }
}
