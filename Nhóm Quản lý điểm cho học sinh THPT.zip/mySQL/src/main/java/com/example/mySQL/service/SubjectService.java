package com.example.mySQL.service;

import com.example.mySQL.model.Subject;
import com.example.mySQL.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SubjectService {

    @Autowired
    private SubjectRepository subjectRepository;

    public List<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    public Subject getSubjectById(String id) {
        Optional<Subject> subjectOpt = subjectRepository.findById(id);
        return subjectOpt.orElse(null);
    }

    public Subject createSubject(Subject subject) {
        return subjectRepository.save(subject);
    }

    public Subject updateSubject(String id, Subject subject) {
        if (subjectRepository.existsById(id)) {
            subject.setSubjectId(id);
            return subjectRepository.save(subject);
        }
        return null;
    }

    public boolean deleteSubject(String id) {
        if (subjectRepository.existsById(id)) {
            subjectRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
