package com.example.mySQL.controller;

import com.example.mySQL.model.Account;
import com.example.mySQL.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @GetMapping
    public List<Account> getAllAccounts() {
        return accountService.getAllAccounts();
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getAccountById(@PathVariable String id) {
        Account account = accountService.getAccountById(id);
        if (account != null) {
            return ResponseEntity.ok(account.toString());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Account with ID " + id + " not found.");
    }

    @PostMapping
    public ResponseEntity<String> createAccount(@RequestBody Account account) {
        Account createdAccount = accountService.createAccount(account);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Account created with ID: " + createdAccount.getAccountId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateAccount(@PathVariable String id, @RequestBody Account account) {
        Account updatedAccount = accountService.updateAccount(id, account);
        if (updatedAccount != null) {
            return ResponseEntity.ok("Account with ID " + id + " has been updated successfully.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Account with ID " + id + " not found.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAccount(@PathVariable String id) {
        boolean isDeleted = accountService.deleteAccount(id);
        if (isDeleted) {
            return ResponseEntity.ok("Account with ID " + id + " has been deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Account with ID " + id + " not found.");
        }
    }
}
