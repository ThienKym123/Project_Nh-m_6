package com.example.mySQL.controller;

import com.example.mySQL.model.ClassAssignment;
import com.example.mySQL.service.ClassAssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/classAssignments")
public class ClassAssignmentController {

    @Autowired
    private ClassAssignmentService classAssignmentService;

    @GetMapping
    public List<ClassAssignment> getAllClassAssignments() {
        return classAssignmentService.getAllClassAssignments();
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getClassAssignmentById(@PathVariable String id) {
        ClassAssignment classAssignment = classAssignmentService.getClassAssignmentById(id);
        if (classAssignment != null) {
            return ResponseEntity.ok(classAssignment.toString());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Class Assignment with ID " + id + " not found.");
    }

    @PostMapping
    public ResponseEntity<String> createClassAssignment(@RequestBody ClassAssignment classAssignment) {
        ClassAssignment createdClassAssignment = classAssignmentService.createClassAssignment(classAssignment);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Class Assignment created with ID: " + createdClassAssignment.getAssignmentId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateClassAssignment(@PathVariable String id, @RequestBody ClassAssignment classAssignment) {
        ClassAssignment updatedClassAssignment = classAssignmentService.updateClassAssignment(id, classAssignment);
        if (updatedClassAssignment != null) {
            return ResponseEntity.ok("Class Assignment with ID " + id + " has been updated successfully.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Class Assignment with ID " + id + " not found.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteClassAssignment(@PathVariable String id) {
        boolean isDeleted = classAssignmentService.deleteClassAssignment(id);
        if (isDeleted) {
            return ResponseEntity.ok("Class Assignment with ID " + id + " has been deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Class Assignment with ID " + id + " not found.");
        }
    }
}
