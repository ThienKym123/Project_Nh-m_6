package com.example.mySQL.controller;

import com.example.mySQL.model.Class;
import com.example.mySQL.service.ClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/classes")
public class ClassController {

    @Autowired
    private ClassService classService;

    // Get all classes
    @GetMapping
    public List<Class> getAllClasses() {
        return classService.getAllClasses();
    }

    // Get class by ID
    @GetMapping("/{id}")
    public ResponseEntity<String> getClassById(@PathVariable String id) {
        Class clazz = classService.getClassById(id);
        if (clazz != null) {
            return ResponseEntity.ok(clazz.getClassName() + " with Homeroom Teacher ID: " + clazz.getHomeroomTeacher());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Class with ID " + id + " not found.");
    }

    // Create a new class
    @PostMapping
    public ResponseEntity<String> createClass(@RequestBody Class clazz) {
        Class createdClass = classService.createClass(clazz);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Class created with ID: " + createdClass.getClassId());
    }

    // Update class by ID
    @PutMapping("/{id}")
    public ResponseEntity<String> updateClass(@PathVariable String id, @RequestBody Class clazz) {
        Class updatedClass = classService.updateClass(id, clazz);
        if (updatedClass != null) {
            return ResponseEntity.ok("Class with ID " + id + " has been updated successfully.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Class with ID " + id + " not found.");
    }

    // Delete class by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteClass(@PathVariable String id) {
        boolean isDeleted = classService.deleteClass(id);
        if (isDeleted) {
            return ResponseEntity.ok("Class with ID " + id + " has been deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Class with ID " + id + " not found.");
        }
    }
}
