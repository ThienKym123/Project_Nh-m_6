package com.example.mySQL.service;

import com.example.mySQL.model.ClassAssignment;
import com.example.mySQL.repository.ClassAssignmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClassAssignmentService {

    @Autowired
    private ClassAssignmentRepository classAssignmentRepository;

    public List<ClassAssignment> getAllClassAssignments() {
        return classAssignmentRepository.findAll();
    }

    public ClassAssignment getClassAssignmentById(String id) {
        Optional<ClassAssignment> classAssignment = classAssignmentRepository.findById(id);
        return classAssignment.orElse(null);
    }

    public ClassAssignment createClassAssignment(ClassAssignment classAssignment) {
        return classAssignmentRepository.save(classAssignment);
    }

    public ClassAssignment updateClassAssignment(String id, ClassAssignment classAssignment) {
        if (classAssignmentRepository.existsById(id)) {
            classAssignment.setAssignmentId(id);
            return classAssignmentRepository.save(classAssignment);
        }
        return null;
    }

    public boolean deleteClassAssignment(String id) {
        if (classAssignmentRepository.existsById(id)) {
            classAssignmentRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
