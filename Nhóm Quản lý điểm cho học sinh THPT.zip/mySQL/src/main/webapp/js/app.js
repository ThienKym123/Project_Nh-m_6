function refreshTrang(){
location.reload();
}

